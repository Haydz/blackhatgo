# bhg
Code samples for the No Starch Press Black Hat Go
